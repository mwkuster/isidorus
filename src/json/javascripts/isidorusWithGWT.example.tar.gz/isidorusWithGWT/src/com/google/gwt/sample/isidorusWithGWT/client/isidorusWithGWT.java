package com.google.gwt.sample.isidorusWithGWT.client;

import com.google.gwt.core.client.EntryPoint;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.VerticalPanel;
import com.google.gwt.user.client.ui.RootPanel;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.FlexTable;
import com.google.gwt.user.client.ui.TextArea;
import com.google.gwt.user.client.ui.ClickListener;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.ui.Widget;
import com.google.gwt.http.client.*;
import com.google.gwt.json.client.JSONParser;
import com.google.gwt.json.client.JSONArray;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.Element;
import com.google.gwt.user.client.DOM;
import com.google.gwt.dom.client.Node;
import com.google.gwt.dom.client.NodeList;
import org.adamtacy.client.ui.NEffectPanel;
import org.adamtacy.client.ui.effects.impl.Fade;


/**
 * Entry point classes define <code>onModuleLoad()</code>.
 */
public class isidorusWithGWT implements EntryPoint
{
	private VerticalPanel mainPanel = new VerticalPanel();
	private FlexTable psiTable = new FlexTable();
	private Button getAllPsisButton = new Button("get all psis");
	private Button clearButton = new Button("clear");
	private TextArea textArea = new TextArea();
	private Button commitButton = new Button("commit via post");
	private Button domButton = new Button("show body child nodes");
	private Button addElemButton = new Button("add node to panel");
	private HorizontalPanel buttonPanel = new HorizontalPanel();
	private final String ALL_PSIS_URL = "http://localhost:8000/json/psis";
	//private final String ALL_PSIS_URL = "http://localhost:8888/com.google.gwt.sample.isidorusWithGWT.isidorusWithGWT/psis.json";
	private final String GET_PREFIX = "http://localhost:8000/json/get/";
	//private final String GET_PREFIX = "http://localhost:8888/com.google.gwt.sample.isidorusWithGWT.isidorusWithGWT/fragment.json";
	private final String OWN_URL = "http://localhost:8000/isidorus";
	//private final String OWN_URL = "http://localhost:8888/com.google.gwt.sample.isidorusWithGWT.isidorusWithGWT/isidorusWithGWT.html";
	private final String COMMIT_URL = "http://localhost:8000/json/commit";
	
	
	// --- entry point
	public void onModuleLoad()
	{
		// --- adds all "static" elements to some panles which are all included in the
		// --- mainPanel of type VertivalPanel which will be added to the RootPanel and
		// --- included to the div with the id "topicList"
		// --- this is the common way to add elements in GWT
		
		textArea.addStyleName("textArea");
		getAllPsisButton.addClickListener(this.getAllPsisButtonHandler());
		mainPanel.addStyleName("mainPanel");
		mainPanel.setBorderWidth(1);
		buttonPanel.add(getAllPsisButton);
		mainPanel.add(buttonPanel);
		clearButton.addClickListener(getClearHandler());
		mainPanel.add(clearButton);
		domButton.addClickListener(getDomButtonHandler());
		mainPanel.add(domButton);
		addElemButton.addClickListener(getAddElemButtonHandler());
		mainPanel.add(addElemButton);
		getAllPsisButton.addStyleName("getAllPsisButton");
		commitButton.addStyleName("commitButton");
		commitButton.addClickListener(getCommitHandler());
		RootPanel.get("topicList").add(mainPanel);
	}
	
	
	// --- creates an onclick Handler for the Button "getAllPsisButton"
	// --- sends a request to the server an gets a list of lists of topic psis
	// --- --> [[topic-1-psi-1, topic-1-psi-2, ...],[topic-2-psi-1, ...], ...].
	// --- if the client-server-communication succeeded, there will be populated the litBox
	// --- element instantiated at the beginning of the main class (listBox) and added to the
	// --- mainPanel.
	private ClickListener getAllPsisButtonHandler()
	{
		return new ClickListener()
		{
			public void onClick(Widget sender)
			{
				RequestBuilder builder = new RequestBuilder(RequestBuilder.GET, URL.encode(ALL_PSIS_URL));
				builder.setHeader("If-Modified-Since", "Thu, 1 Jan 1970 00:00:00 GMT");

				try {
					  Request request = builder.sendRequest(null, new RequestCallback() {
					    public void onError(Request request, Throwable exception) {
					       Window.alert("Something went wrong ...\n" + exception.getMessage());
					    }

					    public void onResponseReceived(Request request, Response response) {
					    	// --- response was ok -> populates the listBox
					    	if (200 == response.getStatusCode()) {
					    		try {
					    			// --- removes the textArea
					    			textArea.setText("");
					    			mainPanel.remove(textArea);
					    			buttonPanel.remove(commitButton);
					    			
					    			// --- clears the psi table
					    			while(psiTable.getRowCount() != 0){
					    				psiTable.removeRow(0);
					    			}
					    			psiTable.setText(0, 0, "#");
					    			psiTable.setText(0, 1, "psi");
					    			
					    			JSONArray json = JSONParser.parse(response.getText()).isArray();
					    			for(int i = 0; i != json.size(); ++i){
					    				JSONArray topic = json.get(i).isArray();
					    				for(int j = 0; j != topic.size(); ++j){
					    					int tableIdx = psiTable.getRowCount(); 
					    					psiTable.setText(tableIdx, 0, Integer.toString(i));
					    					Button psiButton = new Button(topic.get(j).toString().subSequence(1, topic.get(j).toString().length() - 1).toString());
					    					psiButton.addStyleDependentName("psiButton");
					    					psiButton.addClickListener(getFragmentHandler());
					    					NEffectPanel effectPanel = new NEffectPanel();
					    					effectPanel.add(psiButton);
					    					Fade fadeEff = new Fade();
					    					effectPanel.addEffect(fadeEff);
					    					psiTable.setWidget(tableIdx, 1, effectPanel);
					    					effectPanel.playEffects(1.0, 0);
					    				}
					    			}
					    		}
					    		catch(Exception err){
					    			Window.alert("Got bad JSON data ...\n" + err.getMessage());
					    		}
					    	}
					    	else {
					    	  	Window.alert("Something went wrong ...\n" + response.getStatusCode() + ": " + response.getStatusText());
					      }
					    }       
					  });
					  
					  // --- adds the listBox item to the mainPanel
					  if(mainPanel.getWidgetIndex(psiTable) == -1){
						  try {
							  mainPanel.insert(psiTable, mainPanel.getWidgetIndex(clearButton));
						  }
						  catch(Exception err) {
							  mainPanel.add(psiTable);
						  }
					  }
					}
				catch (RequestException err) {
					  Window.alert("Something went wrong ...\n" + err.getMessage());
				}
			}
		};
	}
	
	
	// --- returns a handler for a button which gets a fragment of a specific psi/topic
	private ClickListener getFragmentHandler()
	{
		return new ClickListener()
		{
			public void onClick(Widget sender)
			{
				RequestBuilder builder = new RequestBuilder(RequestBuilder.GET, GET_PREFIX + ((Button)sender).getText().replaceAll("#", "%23"));
				builder.setHeader("If-Modified-Since", "Thu, 1 Jan 1970 00:00:00 GMT");
			
				try {
					Request request = builder.sendRequest(null, new RequestCallback() {
						public void onError(Request request, Throwable exception) {
							Window.alert("Something went wrong ...\n" + exception.getMessage());
						}
	
						public void onResponseReceived(Request request, Response response) {
							// --- response was ok -> populates the listBox
							if (200 == response.getStatusCode()) {
								try {
									// --- removes the psi list
									mainPanel.remove(psiTable);
									
									// --- adds the json string to a textArea
									textArea.setText(response.getText());
									try {
										buttonPanel.add(commitButton);
										mainPanel.insert(textArea, mainPanel.getWidgetIndex(clearButton));										
									}
									catch(Exception err) {
										mainPanel.add(textArea);
									}
								}
								catch(Exception err){
									Window.alert("Got bad JSON data ...\n" + err.getMessage());
								}
							}
							else {
								Window.alert("Something went wrong ...\n" + response.getStatusCode() + ": " + response.getStatusText());
							}
						}       
					});
				}
				catch (RequestException err) {
					Window.alert("Something went wrong ...\n" + err.getMessage());
				}	
			}
		};
	}


	// --- returns a handler for the bottun clearButton, so the initial window will be displayed
	private ClickListener getClearHandler()
	{
		return new ClickListener(){
			public void onClick(Widget sender){
				Window.Location.assign(OWN_URL);
			}
		};
	}


	// --- returns a handler for the button commitButton, so the json-string in the textArea will be commited to the server
	private ClickListener getCommitHandler()
	{
		return new ClickListener(){
			public void onClick(Widget sender){
				RequestBuilder builder = new RequestBuilder(RequestBuilder.POST, URL.encode(COMMIT_URL));
				builder.setHeader("Content-Type", "json/application");
				
				try {
					Request request = builder.sendRequest(textArea.getText(), new RequestCallback() {
						public void onError(Request request, Throwable exception) {
							Window.alert("Something went wrong ...\n" + exception.getMessage());
						}
	
						public void onResponseReceived(Request request, Response response) {
							if (200 == response.getStatusCode()) {
								Window.alert("fragment posted:\n" + textArea.getText());
							}
							else {
								Window.alert("fragment couldn't be posted ...\n" + response.getStatusCode() + "\n" + response.getStatusText());
							}
						}
					});
				}
				catch(Exception err){
					Window.alert("Something went wrong ...\n" + err.getMessage());
				}
			}
		};
	}


	// --- returns a handler for the button dombutton
	private ClickListener getDomButtonHandler()
	{
		return new ClickListener(){
			public void onClick(Widget sender)
			{
				
				NodeList<Node> nodes = RootPanel.getBodyElement().getChildNodes();
				for(int i = 0; i != nodes.getLength(); ++i){
					Window.alert(nodes.getItem(i).getNodeName() + " -> " + nodes.getItem(i).getNodeValue());
				}
			}
		};
	}


	// --- returns a handler for the button addElemButton
	// --- registers also a EventPreview instance for a self-created div-element and inserts the div element
	// --- into the document object model
	private ClickListener getAddElemButtonHandler()
	{
		return new ClickListener(){
			public void onClick(Widget sender)
			{
				String ret = Window.prompt("DIV text content", "Hallo");
				if(ret == null || ret.length() == 0){
					ret = "Hallo";
				}
				
				Element div = DOM.createDiv();
				div.setInnerText(ret);
				div.setClassName("myDiv");
				DOM.insertBefore((Element)clearButton.getElement().getParentElement(), div, clearButton.getElement());
				Label.wrap(div).addClickListener(new ClickListener(){
					public void onClick(Widget sender)
					{
						Window.alert(sender.getElement().getInnerText());
					}
				});
			}
		};
	}
}
