/*
 * Created on May 24, 2006
 * 
 * Copyright 2006, Robert Hanson
 * This library is dustributed under the GNU-LGPL 2.1.
 * http://creativecommons.org/licenses/LGPL/2.1/
 */
package org.hanson.gwt.widgets.client;

public class EffectOption
{
    private String name;
    private String value;

    
    public EffectOption (String name, String value)
    {
        this.name = name;
        this.value = value;
    }

    public EffectOption (String name, double value)
    {
        this.name = name;
        this.value = Double.toString(value);
    }

    
    public String getName ()
    {
        return name;
    }

    public String getValue ()
    {
        return value;
    }

}
